import * as inquirer from "inquirer";
import { Instagram } from "./instagram";

const questions = [{
    type: 'input',
    name: 'username',
    message: 'Type name your girl'
}];

(async () => {
    // const username =  (await inquirer.prompt(questions))['username'];
    const ig = new Instagram();
    await ig.init({
        headless: false,
    }, { width: 1920, height: 1080 });

    // await ig.downloadUserImages('tttthutrang');
    // await ig.login('***@gmail.com', '***');
    // await ig.downloadUserImages('th.keyda');
    await ig.downloadUserImages('itsskylol');
    // await ig.downloadUserImages(username)
    await ig.close();
})();
